export class UserRequest {}
