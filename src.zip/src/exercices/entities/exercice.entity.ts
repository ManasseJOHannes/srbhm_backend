export class Exercice {}
